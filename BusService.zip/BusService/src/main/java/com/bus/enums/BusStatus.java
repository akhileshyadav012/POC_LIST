package com.bus.enums;

public enum BusStatus {
    ACTIVE,
    INACTIVE
}
