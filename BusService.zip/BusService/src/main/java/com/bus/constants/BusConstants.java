package com.bus.constants;

public class BusConstants {
    public static final String ERR_NOT_FOUND = "Bus not Found";
}
