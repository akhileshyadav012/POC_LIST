package com.bus.response;

public interface GetBusesQueryResponse {
    Integer getBus_Id();
    double getDistance();
    double getFare();
}
