package com.user.constants;

public class UserConstants {
    public static final String USER_NOT_FOUND = "User Not Found";
}
