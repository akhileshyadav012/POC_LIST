package com.user.enums;

public enum UserStatus {
    ACTIVE,
    INACTIVE
}
